<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wp23');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'MD5P`f/iZBH/Qa}S.bl~b>~F4Gu9?/k@aH[08G8R @0:[lB%NAWQ)npE%u^;i%4W');
define('SECURE_AUTH_KEY',  '&k/ji{E}WL(q`ewC|T]vv|HgTGF<$S(?,+;&!{OAYra#wCHOrF%m5;Q{hHRrNt0p');
define('LOGGED_IN_KEY',    'MKi$#7DNr[(W.a%Gmw%xB86u7S^^ I#%y4k(y5|CBDaIt;G&jLI2790(lInPK5{K');
define('NONCE_KEY',        'h#<TArf`YI~H}%c]yRhWl3/:xd+XJmU?i1BmL;7P6^QAaxlvBJA %|$9!RiJM4D_');
define('AUTH_SALT',        'BL/1fab]ojVi5`oD|:2U_,qfATpIGZ)lLs9<1#+VSM1U !{wT+kT5F?lm{zV l{e');
define('SECURE_AUTH_SALT', 'h%yH1xL_|Y*aZ38I]qtsHv(Up#0O?;? [kY,Ex4nr:K~_<_ZL}rfd4{Y}d/Y6Y{|');
define('LOGGED_IN_SALT',   '_QU.Jis`O.]k8#_!% PJ(:mZ{8l f[uF|9c{#;#70}BG2<(EgT)e8Z>u wT*4KU+');
define('NONCE_SALT',       'qIs_J*l-R/,XI6$XY$H~667RWiWt5uKllrW/:zk-iL1xAkU]z[)!NF8]?p!A3>]6');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
